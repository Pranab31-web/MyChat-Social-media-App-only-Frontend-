import { useContext, useState } from "react";
import { MyChatContext } from "./store/Context";

function EditingPostForm() {
  const { EditPost, index1, Myposts, imageUploader } =
    useContext(MyChatContext);
  const [newHeading, ChangeNewHeading] = useState(Myposts[index1].Heading);
  const [newContent, ChangeNewContent] = useState(Myposts[index1].Content);
  return (
    <>
      <div
        class="modal fade"
        id="exampleModal"
        tabindex="-1"
        aria-labelledby="exampleModalLabel"
        aria-hidden="true"
      >
        <div class="modal-dialog">
          <div class="modal-content">
            <div class="modal-header">
              <h1 class="modal-title fs-5" id="exampleModalLabel">
                Editing Your Post
              </h1>
              <button
                type="button"
                class="btn-close"
                data-bs-dismiss="modal"
                aria-label="Close"
              ></button>
            </div>
            <div class="modal-body">
              <div id="post">
                <div class="mb-3">
                  <label for="exampleFormControlInput1" class="form-label">
                    <center>Heading of Post</center>
                  </label>
                  <input
                    class="form-control"
                    id="exampleFormControlInput1"
                    value={newHeading}
                    onChange={(e) => {
                      ChangeNewHeading(e.target.value);
                    }}
                  ></input>
                </div>
                <div class="mb-3">
                  <label for="exampleFormControlTextarea1" class="form-label">
                    Content
                  </label>
                  <textarea
                    class="form-control"
                    id="exampleFormControlTextarea1"
                    rows="10"
                    value={newContent}
                    onChange={(e) => {
                      ChangeNewContent(e.target.value);
                    }}
                  ></textarea>
                </div>
              </div>
            </div>
            <div class="modal-footer">
              <button
                type="button"
                class="btn btn-secondary"
                data-bs-dismiss="modal"
              >
                Close
              </button>
              <button
                type="button"
                class="btn btn-primary"
                onClick={() => {
                  EditPost(index1, newHeading, newContent);
                }}
                data-bs-dismiss="modal"
              >
                Save changes
              </button>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}
export default EditingPostForm;
