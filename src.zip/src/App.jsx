import Header from "./header";
import Sidebar from "./Sidebar";
import MainArea from "./mainArea";
import { useState } from "react";
import { MyChatContext } from "./store/Context";

function App() {
  const SidebarComponents = [
    "Profile",
    "Chats",
    "Posts",
    "Following",
    "Followers",
    "Log out",
  ];

  const [Myposts, addPost] = useState([]);
  const [postHeading, addpostHeading] = useState("");
  const [postcontent, addpostcontent] = useState("");
  const [image, addimage] = useState(null);
  const [SearchValue, ChangeSearchValue] = useState("");
  const [FakeMyposts, FakeaddPost] = useState([]);
  const [index, changeIndex] = useState(null);
  const [Loaded, changeLoaded] = useState(true);
  const GetData = async () => {
    try {
      let posts = await fetch("https://dummyjson.com/posts");
      posts = await posts.json();
      posts = posts.posts;
      for (let x of posts) {
        const newpost = {
          Heading: x.title,
          Content: x.body,
        };
        addPost((prevPosts) => {
          const updatedPosts = [...prevPosts, newpost];
          FakeaddPost(updatedPosts);
          return updatedPosts;
        });
      }
      changeLoaded(false);
    } catch {
      console.log("No data received");
      changeLoaded(false);
    }
  };

  if (Loaded == true) {
    GetData();
  }

  const SearchedValue = () => {
    if (String(SearchValue) != "") {
      const FilteredPosts = FakeMyposts.filter((elem) => {
        if (
          elem.Heading.toLowerCase().includes(
            SearchValue.toLowerCase().trim()
          ) ||
          elem.Content.toLowerCase().includes(SearchValue.toLowerCase().trim())
        ) {
          return elem;
        }
      });
      addPost([]);
      addPost(FilteredPosts);
    } else {
      addPost(FakeMyposts);
    }
  };
  const imageUploader = (event) => {
    const file = event.target.files[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = () => {
        addimage(reader.result);
      };
      reader.readAsDataURL(file);
    }
  };
  const addingPost = () => {
    const newpost = {
      Heading: postHeading,
      Content: postcontent,
      Image: image,
    };
    addPost((prevPosts) => {
      const updatedPosts = [newpost, ...prevPosts];
      FakeaddPost(updatedPosts);
      return updatedPosts;
    });
  };
  const DeletePost = (index) => {
    const newarray = Myposts.filter((elem, idx) => {
      if (idx != index) {
        return elem;
      }
    });
    addPost(newarray);
    FakeaddPost(newarray);
  };
  const EditPost = (index, NewHeading, NewContent) => {
    Myposts[index].Heading = NewHeading;
    Myposts[index].Content = NewContent;
    changeIndex(null);
    FakeaddPost(Myposts);
  };

  return (
    <MyChatContext.Provider
      value={{
        addingPost: addingPost,
        addpostHeading: addpostHeading,
        addpostcontent: addpostcontent,
        imageUploader: imageUploader,
        SearchedValue: SearchedValue,
        ChangeSearchValue: ChangeSearchValue,
        Myposts: Myposts,
        SidebarComponents: SidebarComponents,
        DeletePost: DeletePost,
        EditPost: EditPost,
        index1: index,
        addimage: addimage,
      }}
    >
      <Header></Header>
      <div id="centre">
        <Sidebar></Sidebar>
        <MainArea changeIndex={changeIndex} Loaded={Loaded}></MainArea>
      </div>
    </MyChatContext.Provider>
  );
}

export default App;
