import { useContext, useRef } from "react";
import { MyChatContext } from "./store/Context";

function Createpost() {
  const {
    addingPost,
    addpostHeading,
    addpostcontent,
    imageUploader,
    addimage,
  } = useContext(MyChatContext);
  const Heading = useRef("");
  const Content = useRef("");
  const Img = useRef("");

  return (
    <div id="post">
      <div class="mb-3">
        <label for="exampleFormControlInput1" class="form-label">
          <center>Heading of Post</center>
        </label>
        <input
          class="form-control"
          id="exampleFormControlInput1"
          onChange={(e) => {
            addpostHeading(e.target.value);
          }}
          ref={Heading}
        ></input>
      </div>
      <div class="mb-3">
        <label for="exampleFormControlTextarea1" class="form-label">
          Content
        </label>
        <textarea
          class="form-control"
          id="exampleFormControlTextarea1"
          rows="3"
          onChange={(e) => {
            addpostcontent(e.target.value);
          }}
          ref={Content}
        ></textarea>
        <div class="input-group mb-3" id="fileInput">
          <input
            type="file"
            class="form-control"
            id="inputGroupFile02"
            accept="image/*"
            onChange={imageUploader}
            ref={Img}
          ></input>
          <label class="input-group-text" for="inputGroupFile02">
            Upload
          </label>
        </div>
      </div>
      <button
        type="button"
        class="btn btn-success"
        onClick={(e) => {
          addingPost();
          Heading.current.value = "";
          Content.current.value = "";
          Img.current.value = "";
          addpostHeading("");
          addpostcontent("");
          addimage(null);
        }}
      >
        Create Post
      </button>
    </div>
  );
}
export default Createpost;
