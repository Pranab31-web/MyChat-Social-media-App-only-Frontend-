import { useContext, useState } from "react";
import { MyChatContext } from "./store/Context";
import EditingPostForm from "./editPost";

function MainArea({ changeIndex }) {
  const { Myposts, DeletePost, index1 } = useContext(MyChatContext);
  return (
    <div id="MainArea1">
      {Myposts.length > 0 ? (
        Myposts.map((element, index) => (
          <div
            id="MainArea1   "
            class="shadow-lg p-3 mb-5 bg-body-tertiary rounded"
          >
            <center>
              <h3>{element.Heading}</h3>
            </center>
            <div id="flexing">
              <img src={element.Image} id="image" />
              <center id="content">
                <i>{element.Content}</i>
              </center>
            </div>
            <hr />
            <button
              type="button"
              class="btn btn-primary"
              data-bs-toggle="modal"
              data-bs-target="#exampleModal"
              onClick={() => {
                changeIndex(index);
              }}
            >
              Edit Post
            </button>
            {index1 !== null && <EditingPostForm></EditingPostForm>}

            <button
              type="button"
              class="btn btn-danger"
              id="Delete-Button"
              onClick={() => {
                changeIndex(null);
                DeletePost(index);
              }}
            >
              Remove Post
            </button>
          </div>
        ))
      ) : (
        <div id="MainArea">
          <p>No posts Available</p>
        </div>
      )}
    </div>
  );
}
export default MainArea;
