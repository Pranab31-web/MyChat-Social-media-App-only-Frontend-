import Createpost from "./Createpost";
import Chats from "./SidebarComponents/chats";
import Followers from "./SidebarComponents/Followers";
import LogOut from "./SidebarComponents/Log out";
import Posts from "./SidebarComponents/Posts";
import Profile from "./SidebarComponents/Profile";
import Following from "./SidebarComponents/following";
import { useContext } from "react";
import { MyChatContext } from "./store/Context";
function Sidebar() {
  const { SidebarComponents, Myposts } = useContext(MyChatContext);
  const sidebarElem = (element, Myposts) => {
    if (String(element) == "Chats") {
      return <Chats></Chats>;
    } else if (String(element) == "Followers") {
      return <Followers></Followers>;
    } else if (String(element) == "Following") {
      return <Following></Following>;
    } else if (String(element) == "Profile") {
      return <Profile></Profile>;
    } else if (String(element) == "Posts") {
      return <Posts Myposts={Myposts}></Posts>;
    } else if (String(element) == "Log out") {
      return <LogOut></LogOut>;
    }
  };
  return (
    <div id="Sidebar" class="shadow-lg p-3 mb-5 bg-body-tertiary rounded">
      <div class="list-group">
        <center>
          <h4 id="MyAcc">My Account</h4>
        </center>
        {SidebarComponents.map((element, index) => {
          const modalId = `exampleModal-${index}`;
          return (
            <div key={index}>
              <button
                type="button"
                class="btn btn-light"
                data-bs-toggle="modal"
                data-bs-target={`#${modalId}`}
              >
                {element}
              </button>

              <div
                class="modal fade"
                id={modalId}
                tabindex="-1"
                aria-labelledby={`${modalId}-label`}
                aria-hidden="true"
              >
                <div class="modal-dialog">
                  <div class="modal-content">
                    <div class="modal-header">
                      <h1 class="modal-title fs-5" id={`${modalId}-label`}>
                        {element}
                      </h1>
                      <button
                        type="button"
                        class="btn-close"
                        data-bs-dismiss="modal"
                        aria-label="Close"
                      ></button>
                    </div>
                    <div class="modal-body">
                      {sidebarElem(element, Myposts)}
                    </div>
                    <div class="modal-footer">
                      <button
                        type="button"
                        class="btn btn-secondary"
                        data-bs-dismiss="modal"
                      >
                        Close
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          );
        })}
      </div>
      <hr />
      <center>
        <h4 id="MyAcc">Creating a Post</h4>
      </center>
      <Createpost></Createpost>
    </div>
  );
}
export default Sidebar;
