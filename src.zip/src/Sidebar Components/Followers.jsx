function Followers() {
  return (
    <p>
      <b>You have no followers till now</b>
    </p>
  );
}
export default Followers;
