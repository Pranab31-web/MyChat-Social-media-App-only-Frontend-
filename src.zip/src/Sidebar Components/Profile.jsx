function Profile() {
  return (
    <>
      <p>
        <b>Username-prana_bpandey77</b>
      </p>
      <p>
        <b>Name-pranab pandey</b>
      </p>
    </>
  );
}
export default Profile;
