import { useRef } from "react";

function Posts({ Myposts }) {
  return (
    <div id="MainArea1">
      {Myposts.length > 0 ? (
        Myposts.map((element, index) => (
          <div
            id="MainArea1   "
            class="shadow-lg p-3 mb-5 bg-body-tertiary rounded"
          >
            <center>
              <h3>{`${index + 1})  ${element.Heading}`}</h3>
            </center>
          </div>
        ))
      ) : (
        <div id="MainArea">
          <p>No posts Available</p>
        </div>
      )}
    </div>
  );
}
export default Posts;
