function Chats() {
  return (
    <p>
      <b>No Chats to Show Here</b>
    </p>
  );
}
export default Chats;
