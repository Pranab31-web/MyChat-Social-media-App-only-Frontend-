function Following() {
  return (
    <p>
      <b>You are not following anyone till now</b>
    </p>
  );
}
export default Following;
