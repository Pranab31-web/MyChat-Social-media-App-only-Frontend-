import { useContext } from "react";
import Createpost from "./Createpost";
import { MyChatContext } from "./store/Context";
function Header() {
  const { ChangeSearchValue, SearchedValue } = useContext(MyChatContext);
  return (
    <div id="Header">
      <div id="heading">
        <h1 id="mainHeading">
          <b> MyChat</b>
        </h1>
      </div>

      <div id="PostPopup">
        <button
          type="button"
          className="btn btn-success"
          data-bs-toggle="modal"
          data-bs-target="#staticBackdrop"
        >
          New Post
        </button>

        <div
          className="modal fade"
          id="staticBackdrop"
          data-bs-backdrop="static"
          data-bs-keyboard="false"
          tabindex="-1"
          aria-labelledby="staticBackdropLabel"
          aria-hidden="true"
        >
          <div className="modal-dialog">
            <div className="modal-content">
              <div className="modal-header">
                <h1 className="modal-title fs-5" id="staticBackdropLabel">
                  Creating a New Post
                </h1>
                <button
                  type="button"
                  className="btn-close"
                  data-bs-dismiss="modal"
                  aria-label="Close"
                ></button>
              </div>
              <div className="modal-body">
                <Createpost></Createpost>
              </div>
              <div className="modal-footer">
                <button
                  type="button"
                  className="btn btn-secondary"
                  data-bs-dismiss="modal"
                >
                  Close
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
      <input
        type="text"
        placeholder="Search"
        className="form-control me-2"
        id="searchbar"
        onChange={(e) => {
          ChangeSearchValue(e.target.value);
        }}
      />
      <button
        className="btn btn-outline-success"
        id="searchButton"
        type="submit"
        onClick={SearchedValue}
      >
        Search
      </button>
    </div>
  );
}
export default Header;
